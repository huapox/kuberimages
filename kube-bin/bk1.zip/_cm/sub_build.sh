#!/bin/bash

#sh ./bash_build.sh

mkdir -p /down
ls -lh /

