#!/bin/bash
line="-----------------------------------------------------------------"
echo $line
ctdata1=_dockdata1 && hostdata1=_hostdata1 && wgetdata1=_wgetdata1 && dockersys=.dockersys
entry_type_static="base-image"
v_tpl=/$dockersys/.tpl/$entry_type_static

echo "##info ##################"
pwd && ls -l

###################################################################################
function initCnf(){
	echo "##CONF ##################"
	echo "" > /etc/hostname 
	echo "ssh-edge-init" > /etc/hostname
	#hostname -F /etc/hostname ##no permission, docker build --privileged err.
	

	###ping
	chmod u+s /bin/ping
	
	###TODO_DNS
	#[root@read-sup-zipkin-es2 ctoper]# cat /etc/resolv.conf   (this ct, can't use dns like: ping qq.com)
	##nameserver 127.0.0.11  (how this come?)
	#nameserver 114.114.114.114
	#options timeout:2 attempts:3 rotate single-request-reopen ndots:0
	
	###motd
	#echo "" > /etc/motd
	#cat cnf/motd_Buddha > /etc/motd
	echo "welcome to ct~" > /etc/motd
		
	
	###
	sed -i 's^/root:/bin/ash^/root:/bin/bash^g' /etc/passwd ##ROOT bash
	cp cnf/ss.bashrc /root/.bashrc
	cp cnf/ss.profile /root/.profile
	mkdir -p /etc/skel ##oth user init files
	cp cnf/ss.bashrc /etc/skel/.bashrc  ###adduser defalts cnf
	cp cnf/ss.profile /etc/skel/.profile

	###
	cp /etc/apk/repositories /etc/apk/repositories_bk1
	echo "" > /etc/apk/repositories
	#echo "http://mirrors.aliyun.com/alpine/v3.6/main" >> /etc/apk/repositories
	#echo "http://mirrors.aliyun.com/alpine/v3.6/community" >> /etc/apk/repositories
	echo "http://mirrors.ustc.edu.cn/alpine/v3.6/main" >> /etc/apk/repositories
	echo "http://mirrors.ustc.edu.cn/alpine/v3.6/community" >> /etc/apk/repositories
}
echo "---initCnf---" && initCnf

function baseApkIns(){
	echo "##APK ADD ##################"
	apk add --update > /dev/null 2>&1
	apk add bash xterm tmux screen tree wget curl tzdata |grep OK
    ##sh->bash
    mv /bin/sh /bin/busy_sh
    ln -s /bin/bash /bin/sh
	echo "export TERM=xterm" >> /etc/profile
	
	TIMEZONE=Asia/Shanghai #sub_imgs
	ln -snf /usr/share/zoneinfo/$TIMEZONE /etc/localtime && echo $TIMEZONE > /etc/timezone
	
	###oth_lite
	apk add sed |grep OK ##mid-mysql, xxx | sed -s
}
echo "---baseApkIns---" && baseApkIns

####################################################################################
function initSSHServer(){
	echo "##SSH_SERVER ##################"
	apk add openssh |grep OK
	ssh-keygen -f /etc/ssh/ssh_host_rsa_key -N '' -t rsa > /dev/null 2>&1
	
	 #conf
	 cp /etc/ssh/sshd_config /etc/ssh/sshd_config_bk
	
	 #sed -i "s/UsePrivilegeSeparation.*/UsePrivilegeSeparation no/g" /etc/ssh/sshd_config &&\
	 #sed -i "s/#AuthorizedKeysFile/AuthorizedKeysFile/g" /etc/ssh/sshd_config &&\
	 #sed -i "s/#UsePAM.*/UsePAM no/g" /etc/ssh/sshd_config &&\
	 sed -i "s/#PasswordAuthentication.*/PasswordAuthentication yes/g" /etc/ssh/sshd_config &&\
	 sed -i "s/#PubkeyAuthentication.*/PubkeyAuthentication yes/g" /etc/ssh/sshd_config &&\
	 sed -i "s/#PermitRootLogin.*/PermitRootLogin yes/g" /etc/ssh/sshd_config
	
	echo root:132132 |chpasswd > /dev/null 2>&1
	#echo "132132" |su - root -c "echo su-root-sss777-init"
}
#echo "---initSSHServer---" && initSSHServer
apk add openssh |grep OK

function copyCompiled(){
	echo "##N2N_VPN ##################"
	apk add openssl |grep OK
	cp bin/n2n/edge /usr/sbin/
	chmod 751 /usr/sbin/edge
	
	echo "##LRZSZ ##################"
	#tree bin
	cp bin/lrzsz/lsz /usr/bin/sz
	cp bin/lrzsz/lrz /usr/bin/rz
	chmod 751 /usr/bin/sz
	chmod 751 /usr/bin/rz
}
#echo "---copyCompiled---" && copyCompiled

#############################################################################################
echo "##JUMPSER_CT ##################"
  apk add sudo shadow |grep OK
  ##sudo su
  ##sudo: no tty present and no askpass program specified
  #     visiblepw         By default, sudo will refuse to run if the user must enter a password but it is not possible to disable echo on the terminal.  If the visiblepw flag is set, sudo
  #                       will prompt for a password even when it would be visible on the screen.  This makes it possible to run things like “ssh somehost sudo ls” since by default, ssh(1)
  #                       does not allocate a tty when running a command.  This flag is off by default.
  echo "Defaults visiblepw" >> /etc/sudoers


###USER_entry
function initUserEntry(){
	  pw=$(openssl passwd -1 -salt "1234ab5678" secure110)  ##TODO read file
	  useradd -m -d /home/entry -s /bin/bash -p "$pw" -u 664 entry
	
	  #echo "sleep 5" && sleep 5
	  #echo "entry:123456" |chpasswd  ##Password: chpasswd: PAM: Authentication failure
	  echo 'entry ALL = (ALL)  NOPASSWD:ALL' >> /etc/sudoers
}
echo "---initUserEntry---" && initUserEntry

echo 'Cmnd_Alias SU = /bin/su' >> /etc/sudoers
function init_ct_user(){
	  echo $@
	  ct_user=$1
	  ct_key=$2
	  ct_uid=$3
	  ct_sudo=$4
	
	  useradd -m -d /home/$ct_user -s /bin/bash -u $ct_uid $ct_user ## uid: -u 666
	  
	  echo "sleep 2" && sleep 2 ##wait 5 sec, for the user added
	  ##sed -i 's^${ct_user}:!^${ct_user}:no_pw_login!^g' /etc/shadow
	  sed -i "s^${ct_user}\:\!^${ct_user}\:no_pw_login\!^g" /etc/shadow
	
	  mkdir -p /home/$ct_user/.ssh
	  touch /home/$ct_user/.ssh/authorized_keys
	
	  chown $ct_user:$ct_user /home/$ct_user/.ssh -R
	  chmod 700 /home/$ct_user/.ssh
	  chmod 600 /home/$ct_user/.ssh/authorized_keys ## 644 -> 600
	
	  cat $ct_key >> /home/$ct_user/.ssh/authorized_keys  ##TODO: the next add, no split line?
	
	  #echo '%$ct_user        ALL=(ALL)       NOPASSWD: ALL' >> /etc/sudoers
	  #echo 'Cmnd_Alias SU = /bin/su' >> /etc/sudoers
	  if [ "true" = "$ct_sudo" ]; then
	    echo "$ct_user ALL = (root)  NOPASSWD: SU" >> /etc/sudoers
	  fi  
}
echo "---init_ct_user---" && init_ct_user "ctoper" "cnf/sshkey/ctoper_rsa.pub" 665 true
echo "---init_ct_user---" && init_ct_user "ctapp"  "cnf/sshkey/ctapp_rsa.pub" 666 false


#mkdir -p $v_tpl && cp -a tpl/* $v_tpl

#cp cnf/motd_Buddha /$ctdata1/res/
mkdir -p /$dockersys
cp cnf/pw_entry        /$dockersys/.pw_entry
#cp base_entry.sh        /$dockersys/.base_entry.sh

chown -R entry:entry /$dockersys && chmod -R 700 /$dockersys ##Permit
##TODO clean cached apk? APK NOT CACHED

#mkdir -p /$ctdata1/res  ##dir for sub_build.sh (run with root)

echo $line

###temp_link
#sh /_c/base_entry.sh